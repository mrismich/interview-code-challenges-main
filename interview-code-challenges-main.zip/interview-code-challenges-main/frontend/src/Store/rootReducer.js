import { combineReducers } from "@reduxjs/toolkit";
import phones from "./phones";

export default combineReducers({
	phones
});
